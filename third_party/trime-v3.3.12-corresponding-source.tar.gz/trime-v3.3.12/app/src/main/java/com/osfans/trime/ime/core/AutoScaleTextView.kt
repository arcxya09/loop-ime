/*
 * SPDX-FileCopyrightText: 2015 - 2024 Rime community
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
package com.osfans.trime.ime.core

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.widget.TextView
import androidx.core.graphics.withSave
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@SuppressLint("AppCompatCustomView")
class AutoScaleTextView
@JvmOverloads
constructor(
    context: Context?,
    attributeSet: AttributeSet? = null,
) : TextView(context, attributeSet) {
    enum class Mode {
        /**
         * do not scale or ellipse text, overflow when cannot fit width
         */
        None,

        /**
         * only scale in X axis, makes text looks "condensed" or "slim"
         */
        Horizontal,

        /**
         * scale both in X and Y axis, align center vertically
         */
        Proportional,
    }

    var scaleMode = Mode.None

    private lateinit var text: CharSequence

    private var needsMeasureText = true
    private val fontMetrics = Paint.FontMetrics()
    private val textBounds = Rect()

    private var needsCalculateTransform = true
    private var translateY = 0.0f
    private var translateX = 0.0f
    private var textScaleX = 1.0f
    private var textScaleY = 1.0f

    override fun setText(
        charSequence: CharSequence?,
        bufferType: BufferType,
    ) {
        // setText can be called in super constructor
        if (!::text.isInitialized || charSequence == null || !text.contentEquals(charSequence)) {
            needsMeasureText = true
            needsCalculateTransform = true
            text = charSequence ?: ""
            requestLayout()
            invalidate()
        }
    }

    override fun getText(): CharSequence = text

    override fun onMeasure(
        widthMeasureSpec: Int,
        heightMeasureSpec: Int,
    ) {
        val widthMode = MeasureSpec.getMode(widthMeasureSpec)
        val widthSize = MeasureSpec.getSize(widthMeasureSpec)
        val heightMode = MeasureSpec.getMode(heightMeasureSpec)
        val heightSize = MeasureSpec.getSize(heightMeasureSpec)
        val width = measureTextBounds().width() + paddingLeft + paddingRight
        val height = ceil(fontMetrics.bottom - fontMetrics.top + paddingTop + paddingBottom).toInt()
        val maxHeight = if (maxHeight >= 0) maxHeight else Int.MAX_VALUE
        val maxWidth = if (maxWidth >= 0) maxWidth else Int.MAX_VALUE
        setMeasuredDimension(
            measure(widthMode, widthSize, min(max(width, minimumWidth), maxWidth)),
            measure(heightMode, heightSize, min(max(height, minimumHeight), maxHeight)),
        )
    }

    private fun measure(
        specMode: Int,
        specSize: Int,
        calculatedSize: Int,
    ): Int = when (specMode) {
        MeasureSpec.EXACTLY -> specSize
        MeasureSpec.AT_MOST -> min(calculatedSize, specSize)
        else -> calculatedSize
    }

    private fun measureTextBounds(): Rect {
        if (needsMeasureText) {
            val paint = paint
            paint.getFontMetrics(fontMetrics)
            val codePointCount = Character.codePointCount(text, 0, text.length)
            if (codePointCount == 1) {
                // use actual text bounds when there is only one "character",
                // eg. full-width punctuation
                CharArray(text.length).also {
                    TextUtils.getChars(text, 0, text.length, it, 0)
                    paint.getTextBounds(it, 0, text.length, textBounds)
                }
            } else {
                textBounds.set(
                    // left =
                    0,
                    // top =
                    floor(fontMetrics.top).toInt(),
                    // right =
                    ceil(paint.measureText(text, 0, text.length)).toInt(),
                    // bottom =
                    ceil(fontMetrics.bottom).toInt(),
                )
            }
            needsMeasureText = false
        }
        return textBounds
    }

    override fun onSizeChanged(
        w: Int,
        h: Int,
        oldw: Int,
        oldh: Int,
    ) {
        super.onSizeChanged(w, h, oldw, oldh)
        needsCalculateTransform = true
        needsMeasureText = true
    }

    override fun onLayout(
        changed: Boolean,
        left: Int,
        top: Int,
        right: Int,
        bottom: Int,
    ) {
        if (needsCalculateTransform) {
            calculateTransform(right - left, bottom - top)
            needsCalculateTransform = false
        }
    }

    private fun calculateTransform(
        viewWidth: Int,
        viewHeight: Int,
    ) {
        val contentWidth = viewWidth - paddingLeft - paddingRight
        val contentHeight = viewHeight - paddingTop - paddingBottom
        measureTextBounds()
        val textWidth = textBounds.width()
        val textHeight = textBounds.height()

        // Prevent division by zero: if text dimensions are zero
        if (textWidth == 0 || textHeight == 0) {
            textScaleX = 1.0f
            textScaleY = 1.0f
            translateX = 0f
            translateY = 0f
            return
        }

        @SuppressLint("RtlHardcoded")
        val shouldAlignLeft = gravity and Gravity.HORIZONTAL_GRAVITY_MASK == Gravity.LEFT

        if (textWidth > contentWidth || textHeight > contentHeight) {
            when (scaleMode) {
                Mode.None -> {
                    textScaleX = 1.0f
                    textScaleY = 1.0f
                    translateX = calculateTranslateX(contentWidth, textWidth, 1.0f, shouldAlignLeft)
                }
                Mode.Horizontal -> {
                    textScaleX = contentWidth.toFloat() / textWidth.toFloat()
                    textScaleY = 1.0f
                    translateX = calculateTranslateX(contentWidth, textWidth, textScaleX, shouldAlignLeft)
                }
                Mode.Proportional -> {
                    val textXScale = contentWidth.toFloat() / textWidth.toFloat()
                    val textYScale = contentHeight.toFloat() / textHeight.toFloat()
                    val textScale = min(textXScale, textYScale)
                    textScaleX = textScale
                    textScaleY = textScale
                    translateX = calculateTranslateX(contentWidth, textWidth, textScaleX, shouldAlignLeft)
                }
            }
        } else {
            translateX = calculateTranslateX(contentWidth, textWidth, 1.0f, shouldAlignLeft)
            textScaleX = 1.0f
            textScaleY = 1.0f
        }
        val fontHeight = (fontMetrics.descent - fontMetrics.ascent) * textScaleY
        val fontOffsetY = fontMetrics.ascent * textScaleY
        translateY = (contentHeight.toFloat() - fontHeight) / 2.0f - fontOffsetY + paddingTop
    }

    private fun calculateTranslateX(
        contentWidth: Int,
        textWidth: Int,
        scaleX: Float,
        shouldAlignLeft: Boolean,
    ): Float {
        val scaledTextWidth = textWidth * scaleX
        val startX = if (shouldAlignLeft) {
            paddingLeft.toFloat()
        } else {
            paddingLeft.toFloat() + (contentWidth - scaledTextWidth) / 2.0f
        }
        return (startX - textBounds.left) / scaleX
    }

    override fun onDraw(canvas: Canvas) {
        if (needsCalculateTransform) {
            calculateTransform(width, height)
            needsCalculateTransform = false
        }
        val paint = paint
        paint.color = currentTextColor
        canvas.withSave {
            translate(scrollX.toFloat(), scrollY.toFloat())
            scale(textScaleX, textScaleY, 0f, translateY)
            translate(translateX, translateY)
            drawText(text, 0, text.length, 0f, 0f, paint)
        }
    }

    override fun getTextScaleX(): Float = textScaleX

    override fun getBaseline(): Int {
        val baseline = -fontMetrics.top * textScaleY
        // Prevent NaN or Infinity from causing crash
        return if (baseline.isNaN() || baseline.isInfinite()) {
            super.getBaseline()
        } else {
            baseline.roundToInt()
        }
    }
}
